package adapterpattern;

public class SquareShape {
	public void colourSquare(String color) {
		System.out.println("Square color is " + color);
	}
}
