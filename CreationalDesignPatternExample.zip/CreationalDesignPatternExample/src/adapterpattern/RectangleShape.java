package adapterpattern;

public class RectangleShape {
	
	public void colourRectangle(String color) {
		System.out.println("Rectangle color is " + color);
	}

}
