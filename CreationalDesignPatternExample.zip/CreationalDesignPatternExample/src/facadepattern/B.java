package facadepattern;

public class B {
	
	
	
	public float someCodeToDoubleCubeValue(float a,A aclass) {
		return 2 * aclass.someCode(a);
	} 

}
