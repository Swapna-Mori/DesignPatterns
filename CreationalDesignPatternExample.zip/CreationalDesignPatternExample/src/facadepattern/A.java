package facadepattern;

public class A {
	
	public float someCode(float a) {
		return a * a * a;
	}
	
	

}
