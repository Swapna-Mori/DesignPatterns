package facadepattern;

public class C {
	

	public float doMuliplicationofCubeAndDoubleValueOfCube(float z,A aclass,B bclass) {
		return aclass.someCode(z) * bclass.someCodeToDoubleCubeValue(z,aclass);
		
	}
}
