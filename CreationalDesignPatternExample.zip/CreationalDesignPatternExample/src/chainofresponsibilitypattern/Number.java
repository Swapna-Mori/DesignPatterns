package chainofresponsibilitypattern;

public class Number {
	
	private int number;

	public Number(int i) {
		this.number = i;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	

}
