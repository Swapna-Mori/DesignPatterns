package factorypatternexample;

public class Circle implements Shape{

	@Override
	public void calculate() {
		System.out.println("This is Circle calculate method");
		
	}

}
