package factorypatternexample;

public interface Shape {
	public void calculate();
}
