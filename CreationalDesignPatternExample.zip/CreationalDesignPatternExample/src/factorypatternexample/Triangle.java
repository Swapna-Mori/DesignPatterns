package factorypatternexample;

public class Triangle implements Shape{

	@Override
	public void calculate() {
		System.out.println("This is Triange calculate method");
		
	}

}
