package factorypatternexample;

public class Rectangle implements Shape{

	@Override
	public void calculate() {
		System.out.println("This is rectangle calculate method");
		
	}

}
