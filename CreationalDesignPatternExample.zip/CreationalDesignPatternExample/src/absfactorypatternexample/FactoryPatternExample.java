package absfactorypatternexample;

public class FactoryPatternExample {

	public static void main(String[] args) {
		
		System.out.println(ShapeFactory.getShape(ShapeSides.ZERO));

	}

}
