package absfactorypatternexample;

public class FactoryPatternExample {

	public static void main(String[] args) {
		
		System.out.println(AreaFactory.calculateShapeArea(ShapeSides.FOUR));

	}

}
