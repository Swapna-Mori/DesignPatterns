package absfactorypatternexample;

public enum Area {

	CIRCLEAREA,
	RECTANGLEAREA,
	TRIANGLEAREA,
	DEFAULT
}
