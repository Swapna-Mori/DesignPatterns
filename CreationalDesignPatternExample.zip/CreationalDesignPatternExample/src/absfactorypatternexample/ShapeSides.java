package absfactorypatternexample;

public enum ShapeSides {
	ZERO,ONE,TWO,THREE,FOUR

}
